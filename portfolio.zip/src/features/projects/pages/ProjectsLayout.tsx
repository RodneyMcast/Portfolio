import { Outlet } from 'react-router-dom';

export const ProjectsLayout = () => (
  <section className="page">
    <Outlet />
  </section>
);
