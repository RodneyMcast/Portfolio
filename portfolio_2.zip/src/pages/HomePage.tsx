import { HomeHero } from "../components/home/HomeHero";

export const HomePage = () => (
  <section className="page">
    <HomeHero />
  </section>
);
