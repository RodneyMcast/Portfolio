export const FullPageLoader = () => (
  <div className="full-page-loader" role="status" aria-live="polite">
    <span>Loading...</span>
  </div>
);
