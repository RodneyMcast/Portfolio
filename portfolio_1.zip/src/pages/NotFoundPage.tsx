export const NotFoundPage = () => (
  <section className="page">
    <span className="eyebrow">404</span>
    <h1>Page not found</h1>
    <p>Try one of the links in the menu.</p>
  </section>
);
